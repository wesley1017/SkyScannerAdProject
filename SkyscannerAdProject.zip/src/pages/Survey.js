import React from "react";

function Survey() {
  return (
    <div>
      <h2>User Survey</h2>
      <p>Collect user feedback on ads.</p>
    </div>
  );
}

export default Survey;
