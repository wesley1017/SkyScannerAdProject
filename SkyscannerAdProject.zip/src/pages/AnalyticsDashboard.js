import React from "react";

function AnalyticsDashboard() {
  return (
    <div>
      <h2>Analytics Dashboard</h2>
      <p>View ad performance metrics here.</p>
    </div>
  );
}

export default AnalyticsDashboard;
