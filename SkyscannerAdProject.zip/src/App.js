import React from "react";
import AdSelection from "./components/AdSelection";
import AnalyticsDashboard from "./pages/AnalyticsDashboard";
import Survey from "./pages/Survey";

function App() {
  return (
    <div>
      <h1>Skyscanner Ad Management</h1>
      <AdSelection />
      <AnalyticsDashboard />
      <Survey />
    </div>
  );
}

export default App;
