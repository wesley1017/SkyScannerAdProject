import React from "react";

function AdSelection() {
  return (
    <div>
      <h2>Choose Ad Type</h2>
      <button>Text Ad</button>
      <button>Image & Text Ad</button>
      <button>Video Ad</button>
    </div>
  );
}

export default AdSelection;
